import army_web from "../src/assets/images/army_web.png";
import organic from "../src/assets/images/organic.png";
import expense from "../src/assets/images/expense.png";

const logotext = "VIKRAM BALASAHEB MANE";
const meta = {
  title: "Vikram Mane",
  description:
    "I’m Vikram Mane Front-End Developer,currently working in Metamind Systems Pvt Ltd",
};

const introdata = {
  title: "I’m Vikram Mane",
  animated: {
    first: "I love coding",
    second: "I code cool websites",
    third: "I develop web apps",
  },
  description: "To know more about my work please checkout my portfolio",
};

const dataabout = {
  title: "abit about my self",
  aboutme:
    "Hello and welcome to my portfolio! I'm Vikram, a passionate Software Developer with a love for Front-End Development. With 1.3 years of experience in developing web app's, I'm dedicated to develope web app's that not only meets but exceeds expectations.I'm constantly seeking new challenges and opportunities to grow both personally and professionally. Let's connect and explore how we can collaborate to bring your ideas to life.Thank you for stopping by, and I look forward to connecting with you!",
};
const worktimeline = [
  {
    jobtitle: "Front-End Developer",
    where: "Pune",
    date: "2023",
  },
];

const skills = [
  {
    name: "Core Java",
    value: 90,
  },
  {
    name: "JavaScript",
    value: 90,
  },
  {
    name: "React.js",
    value: 90,
  },
  {
    name: "React-Redux-Saga",
    value: 90,
  },
  {
    name: "React-Redux-Toolkit",
    value: 90,
  },
  {
    name: "Bootstarp-Antd",
    value: 90,
  },
  {
    name: "Jquery",
    value: 85,
  },
  {
    name: "Ajax",
    value: 90,
  },
  {
    name: "HTML",
    value: 95,
  },
];

const services = [
  {
    title: "UI & UX Design",
    description: "I can design cool and best designs for the web applications.",
  },
  {
    title: "Web Apps",
    description: "I can develope responsive web applications.",
  },
];

const dataportfolio = [
  {
    img: army_web,
    description:
      "Army Hostel Web is to avail the services, granted for Army Served/Serving Soldier's childrens.",
    link: "#",
  },
  {
    img: organic,
    description:
      "Organic Farming is helpful web for those who are looking for the organic food at their door.",
    link: "#",
  },
  {
    img: expense,
    description:
      "Expense Management is a modal that will do the entire handeling of expense for organisation.",
    link: "#",
  },
 
];

const contactConfig = {
  YOUR_EMAIL: "mvikram104@gmail.com",
  YOUR_FONE: "+91-9404544434",
  description:
    "Thank you for taking the time to visit my portfolio! If you have any inquiries, feedback, or collaboration opportunities, please don't hesitate to get in touch using the form below or via email at above email. I'm always eager to connect with fellow professionals and enthusiasts alike. Looking forward to hearing from you! ",
  // creat an emailjs.com account
  // check out this tutorial https://www.emailjs.com/docs/examples/reactjs/
  YOUR_SERVICE_ID: "service_id",
  YOUR_TEMPLATE_ID: "template_id",
  YOUR_USER_ID: "user_id",
};

const socialprofils = {
  github: "https://github.com/vikram2547",
  facebook: "https://facebook.com",
  linkedin: "https://www.linkedin.com/in/vikram-mane-702a8b16a/",
  twitter: "https://twitter.com",
};
export {
  meta,
  dataabout,
  dataportfolio,
  worktimeline,
  skills,
  services,
  introdata,
  contactConfig,
  socialprofils,
  logotext,
};
